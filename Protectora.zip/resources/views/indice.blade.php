@extends('plantilla')

@section('title') Indice @endsection

@section('content')
<div class="container">
    @for ($i = 1; $i <= 26; $i++)
        <p>Esta es la linea {{ $i }}</p>
    @endfor
</div>
@endsection

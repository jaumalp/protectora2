@if (true)
    <img 
@endif

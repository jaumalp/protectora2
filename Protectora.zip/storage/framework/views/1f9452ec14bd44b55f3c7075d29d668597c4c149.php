<?php if(true): ?>
    <img 
<?php endif; ?>

<!-- Menu para moviles -->
<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top
              border rounded-bottom shadow">

    <div class="navbar-toggler border-0 text-center"
         data-toggle="collapse" data-target="#navbarSupportedContent"
         aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="text-primary text-left">¡BIENVENIDO AMIG@!</span>
    </div>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto pl-3">
        <li class="nav-item">
          <a class="nav-link" href="#">¿Vamos al inicio?</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">¿Quieres ayudar?</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">¿Buscas un amigo?</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">¿Quieres conocernos?</a>
        </li>
      </ul>
    </div>
  </nav>
<!-- /Menu moviles -->

